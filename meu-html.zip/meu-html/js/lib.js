import { PWButton } from "./pwbutton.js";
import { PWTitle } from "./pwtitle.js";

customElements.define('pw-button', PWButton);
customElements.define('pw-title', PWTitle);